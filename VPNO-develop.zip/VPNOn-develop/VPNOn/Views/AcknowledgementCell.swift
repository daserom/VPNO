//
//  AcknowledgementCell.swift
//  VPNOn
//
//  Created by Lex on 10/31/15.
//  Copyright © 2017 lexrus.com. All rights reserved.
//

import UIKit

class AcknowledgementCell : UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var contentLabel: UILabel!

}
