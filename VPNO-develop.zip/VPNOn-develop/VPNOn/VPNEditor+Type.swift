//
//  VPNEditor+Type.swift
//  VPNOn
//
//  Created by Lex Tang on 1/23/15.
//  Copyright (c) 2017 lexrus.com. All rights reserved.
//

import UIKit

extension VPNEditor {

    @IBAction func didChangeType(_ sender: AnyObject) {
        toggleSaveButtonByStatus()
    }

}
